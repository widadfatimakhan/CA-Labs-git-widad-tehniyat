`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/05/2026 10:15:01 AM
// Design Name: 
// Module Name: seven_seg
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module seven_seg (
    input clk,             // System clock
    input [15:0] value,         // 16-bit value to show
    output reg [6:0] segments,    // Segments a-g
    output reg [3:0] an    // Anode selectors
);
    // Counter to drive the display multiplexing rate
    reg [17:0] refresh;
    always @(posedge clk) refresh <= refresh + 1;

    reg [3:0] nibble_to_show;
    
    // Selection logic: Cycles through anodes based on the scan counter
    always @(*) begin
        case(refresh[17:16])
            // Rightmost position - Units
            2'b00: begin 
                nibble_to_show = value % 10; 
                an = 4'b1110; 
            end
            // Second position - Tens
            2'b01: begin 
                nibble_to_show = (value / 10) % 10; 
                an = 4'b1101; 
            end
            // Third position - Hundreds
            2'b10: begin 
                nibble_to_show = (value / 100) % 10; 
                an = 4'b1011; 
            end
            // Leftmost position - Thousands
            2'b11: begin 
                nibble_to_show = (value / 1000) % 10; 
                an = 4'b0111; 
            end
        endcase
    end

    // Cathode Map: Converts decimal digit to 7-segment pattern (active low)
    always @(*) begin
        case(nibble_to_show)
            0: segments = 7'b1000000; 
            1: segments = 7'b1111001; 
            2: segments = 7'b0100100;
            3: segments = 7'b0110000; 
            4: segments = 7'b0011001; 
            5: segments = 7'b0010010;
            6: segments = 7'b0000010; 
            7: segments = 7'b1111000; 
            8: segments = 7'b0000000;
            9: segments = 7'b0010000; 
            default: segments = 7'b1111111; // Blank display
        endcase
    end
endmodule
