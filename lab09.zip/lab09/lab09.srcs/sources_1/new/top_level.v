`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/26/2026 11:10:12 AM
// Design Name: 
// Module Name: top_level
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_level (
    input        clk,
    input        rst,
    input        btn_next,
    input [15:0] sw,
    output [15:0] led
);

    // --- debounce the next button ---
    wire btn_db;
    button_debounce U_DB (
        .clk(clk), .pbin(btn_next), .pbout(btn_db)
    );

    // --- read switches (Lab 5 switches module) ---
    wire [31:0] sw_readData;
    switches U_SW (
        .clk(clk), .rst(rst),
        .btns(16'b0),
        .writeData(32'b0), .writeEnable(1'b0), .readEnable(1'b1),
        .memAddress(30'b0),
        .switches(sw),
        .readData(sw_readData)
    );
    wire [15:0] sw_val = sw_readData[15:0]; // clean registered switch values

    // --- FSM instruction ROM ---
    localparam N = 15;
    reg [3:0]  idx;
    reg [16:0] rom [0:N-1];
    reg        btn_prev;

    initial begin
        rom[0]  = {7'b0110011, 3'b000, 7'b0000000}; // ADD
        rom[1]  = {7'b0110011, 3'b000, 7'b0100000}; // SUB
        rom[2]  = {7'b0110011, 3'b001, 7'b0000000}; // SLL
        rom[3]  = {7'b0110011, 3'b101, 7'b0000000}; // SRL
        rom[4]  = {7'b0110011, 3'b111, 7'b0000000}; // AND
        rom[5]  = {7'b0110011, 3'b110, 7'b0000000}; // OR
        rom[6]  = {7'b0110011, 3'b100, 7'b0000000}; // XOR
        rom[7]  = {7'b0010011, 3'b000, 7'b0000000}; // ADDI
        rom[8]  = {7'b0000011, 3'b010, 7'b0000000}; // LW
        rom[9]  = {7'b0000011, 3'b001, 7'b0000000}; // LH
        rom[10] = {7'b0000011, 3'b000, 7'b0000000}; // LB
        rom[11] = {7'b0100011, 3'b010, 7'b0000000}; // SW
        rom[12] = {7'b0100011, 3'b001, 7'b0000000}; // SH
        rom[13] = {7'b0100011, 3'b000, 7'b0000000}; // SB
        rom[14] = {7'b1100011, 3'b000, 7'b0000000}; // BEQ
    end

    // advance index on rising edge of debounced button (only in auto mode)
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            idx      <= 0;
            btn_prev <= 0;
        end else begin
            btn_prev <= btn_db;
            if (btn_db && !btn_prev && sw_val[15])
                idx <= (idx == N-1) ? 0 : idx + 1;
        end
    end

    // SW[15]=0: manual - switches set opcode/funct3/funct7 directly
    // SW[15]=1: auto   - FSM steps through ROM entries
    wire [6:0] opcode = sw_val[15] ? rom[idx][16:10] : sw_val[6:0];
    wire [2:0] funct3 = sw_val[15] ? rom[idx][9:7]   : sw_val[9:7];
    wire [6:0] funct7 = sw_val[15] ? rom[idx][6:0]   : {6'b0, sw_val[10]};

    // --- control units ---
    wire RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUControl;

    MainControl U_MC (
        .opcode(opcode), .RegWrite(RegWrite), .ALUOp(ALUOp),
        .MemRead(MemRead), .MemWrite(MemWrite), .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg), .Branch(Branch)
    );

    ALUControl U_AC (
        .opcode(opcode), .ALUOp(ALUOp), .funct3(funct3),
        .funct7(funct7), .ALUControl(ALUControl)
    );

    // --- drive LEDs (Lab 5 leds module) ---
    // LED mapping:
    // [0]=RegWrite [1]=ALUSrc [2]=MemRead [3]=MemWrite
    // [4]=MemtoReg [5]=Branch [9:6]=ALUControl [15]=mode
    wire [15:0] led_data = {sw_val[15], 5'b0, ALUControl,
                            Branch, MemtoReg, MemWrite,
                            MemRead, ALUSrc, RegWrite};

    leds U_LEDS (
        .clk(clk), .rst(rst),
        .writeData({16'b0, led_data}),
        .writeEnable(1'b1),
        .readEnable(1'b0),
        .memAddress(30'b0),
        .readData(),
        .leds(led)
    );

endmodule