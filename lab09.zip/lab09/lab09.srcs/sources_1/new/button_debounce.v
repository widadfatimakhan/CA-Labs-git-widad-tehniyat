`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/26/2026 11:11:06 AM
// Design Name: 
// Module Name: button_debounce
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//`timescale 1ns / 1ps
//module button_debounce #(parameter CW = 20)(
//    input  clk, reset, btn_in,
//    output reg btn_debounced,
//    output reg btn_pulse
//);
//    reg [CW-1:0] counter;
//    reg s0, s1, btn_prev;

//    always @(posedge clk or posedge reset) begin
//        if (reset) begin s0<=0; s1<=0; end
//        else       begin s0<=btn_in; s1<=s0; end
//    end

//    always @(posedge clk or posedge reset) begin
//        if (reset) begin
//            counter<=0; btn_debounced<=0; btn_pulse<=0; btn_prev<=0;
//        end else begin
//            btn_pulse <= 0;
//            if (s1 != btn_debounced) begin
//                counter <= counter + 1;
//                if (counter == {CW{1'b1}}) begin
//                    btn_debounced <= s1; counter <= 0;
//                end
//            end else counter <= 0;

//            btn_prev <= btn_debounced;
//            if (btn_debounced && !btn_prev) btn_pulse <= 1;
//        end
//    end
//endmodule

module button_debounce(
    input clk,
    input pbin,
    output reg pbout
);
 
    reg [2:0] shift;
 
    always @(posedge clk) begin
        shift <= {shift[1:0], pbin};
        if (shift == 3'b111)
            pbout <= 1;
        else if (shift == 3'b000)
            pbout <= 0;
    end
 
endmodule