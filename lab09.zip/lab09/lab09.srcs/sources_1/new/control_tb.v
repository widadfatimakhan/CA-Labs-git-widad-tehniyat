`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/26/2026 11:06:27 AM
// Design Name: 
// Module Name: control_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module control_tb;

    reg  [6:0] opcode;
    reg  [2:0] funct3;
    reg  [6:0] funct7;

    wire RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUControl;

    MainControl mc (
        .opcode(opcode), .RegWrite(RegWrite), .ALUOp(ALUOp),
        .MemRead(MemRead), .MemWrite(MemWrite), .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg), .Branch(Branch)
    );

    ALUControl alu_ctrl (
        .opcode(opcode), .ALUOp(ALUOp), .funct3(funct3),
        .funct7(funct7), .ALUControl(ALUControl)
    );

    task show; input [63:0] name;
        $display("%s | %b %b %b | RW=%b ALUOp=%b MR=%b MW=%b AS=%b M2R=%b BR=%b ALUC=%b",
            name, opcode, funct3, funct7,
            RegWrite, ALUOp, MemRead, MemWrite,
            ALUSrc, MemtoReg, Branch, ALUControl);
    endtask

    initial begin
        $dumpfile("control_tb.vcd");
        $dumpvars(0, control_tb);
        $display("Instr | opcode  funct3 funct7  | RW ALUOp MR MW AS M2R BR ALUC");
        $display("--------------------------------------------------------------");

        // R-type
        opcode=7'b0110011; funct3=3'b000; funct7=7'b0000000; #10; show("ADD ");
        opcode=7'b0110011; funct3=3'b000; funct7=7'b0100000; #10; show("SUB ");
        opcode=7'b0110011; funct3=3'b001; funct7=7'b0000000; #10; show("SLL ");
        opcode=7'b0110011; funct3=3'b101; funct7=7'b0000000; #10; show("SRL ");
        opcode=7'b0110011; funct3=3'b111; funct7=7'b0000000; #10; show("AND ");
        opcode=7'b0110011; funct3=3'b110; funct7=7'b0000000; #10; show("OR  ");
        opcode=7'b0110011; funct3=3'b100; funct7=7'b0000000; #10; show("XOR ");

        // I-type
        opcode=7'b0010011; funct3=3'b000; funct7=7'b0000000; #10; show("ADDI");

        // Load
        opcode=7'b0000011; funct3=3'b010; funct7=7'b0000000; #10; show("LW  ");
        opcode=7'b0000011; funct3=3'b001; funct7=7'b0000000; #10; show("LH  ");
        opcode=7'b0000011; funct3=3'b000; funct7=7'b0000000; #10; show("LB  ");

        // Store
        opcode=7'b0100011; funct3=3'b010; funct7=7'b0000000; #10; show("SW  ");
        opcode=7'b0100011; funct3=3'b001; funct7=7'b0000000; #10; show("SH  ");
        opcode=7'b0100011; funct3=3'b000; funct7=7'b0000000; #10; show("SB  ");

        // Branch
        opcode=7'b1100011; funct3=3'b000; funct7=7'b0000000; #10; show("BEQ ");

        // Unknown
        opcode=7'b1111111; funct3=3'b000; funct7=7'b0000000; #10; show("UNK ");

        $finish;
    end
endmodule
