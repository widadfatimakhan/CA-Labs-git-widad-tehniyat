`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/11/2026 11:54:26 AM
// Design Name: 
// Module Name: instructionMemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//module instructionMemory#(
//    parameter OPERAND_LENGTH = 31
//)(
//    input [OPERAND_LENGTH:0] instAddress,
//    output reg [31:0] instruction
//);
 
//    reg [7:0] memory [0:255];
 
//    initial begin
//        $readmemh("mem_file.mem", memory);
//    end
 
 
//    always @(*) begin
//        instruction = {memory[instAddress + 3], 
//                       memory[instAddress + 2], 
//                       memory[instAddress + 1], 
//                       memory[instAddress]};
//    end
//endmodule

module instructionMemory #(
    parameter OPERAND_LENGTH = 31,
    parameter MEM_FILE       = "mem_file.mem"
)(
    input  wire [OPERAND_LENGTH:0] instAddress,
    output wire [31:0]             instruction
);
    reg [31:0] memory [0:255];
 
    initial begin
        $readmemh(MEM_FILE, memory);
    end
 
    // Word-aligned fetch: PC is a byte address; drop the low 2 bits.
    assign instruction = memory[instAddress[9:2]];
endmodule
