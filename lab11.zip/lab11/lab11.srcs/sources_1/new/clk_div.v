`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/24/2026 03:59:37 PM
// Design Name: 
// Module Name: clk_div
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clk_divider(
    input  wire clk_in,    // 100 MHz
    input  wire rst,
    output reg  clk_out    // 10 MHz
);
    reg [2:0] counter;
    always @(posedge clk_in or posedge rst) begin
        if (rst) begin
            counter <= 3'd0;
            clk_out <= 1'b0;
        end else begin
            if (counter == 3'd4) begin
                counter <= 3'd0;
                clk_out <= ~clk_out;
            end else begin
                counter <= counter + 3'd1;
            end
        end
    end
endmodule