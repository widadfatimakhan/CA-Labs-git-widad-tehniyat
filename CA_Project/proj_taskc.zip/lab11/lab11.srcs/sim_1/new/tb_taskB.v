`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module:  tb_taskC
//
// Project Task C testbench - Fibonacci sequence.
//
// HOW TO USE IN VIVADO:
//   1. Add task_c_sim.mem to your Simulation Sources (separate from task_c.mem)
//   2. Set tb_taskC as the simulation top
//   3. Run simulation for 10 us (set in toolbar)
//
// SIGNALS TO ADD TO WAVEFORM WINDOW (from Objects panel):
//   led_data_reg  - radix: Unsigned Decimal
//                   Shows: 0, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, reset...
//                   (double writes are normal - one on entry to subroutine,
//                    one on exit from DELAY)
//   sp            - radix: Hex
//                   Should be 0x1F0 normally, drops to 0x1E8 inside
//                   SHOW_AND_DELAY (proves the -8 stack frame allocation)
//   ra            - radix: Hex
//                   Changes on every JAL instruction
//   s0, s1, s2    - radix: Unsigned Decimal
//                   Previous, current, and next Fibonacci values
//   pc            - radix: Hex
//                   Walks through the program
//   instruction   - radix: Hex
//                   Shows what instruction is executing
//
// NOTE: This testbench uses task_c_sim.mem which has DELAY=2 (instead of 20).
//       This makes each Fibonacci value display in ~300 ns instead of ~8800 ns.
//       The hardware file task_c.mem with DELAY=20 is untouched.
//////////////////////////////////////////////////////////////////////////////////
module tb_taskC;

    reg         clk;
    reg         reset;
    reg [15:0]  switch_in;
    wire [15:0] leds;

    // ---- DUT: task_c_sim.mem has DELAY=2 for fast simulation ----
    TopLevelFPGA #(.MEM_FILE("taskc_sim.mem")) dut (
        .clk       (clk),
        .reset     (reset),
        .switch_in (switch_in),
        .leds      (leds)
    );

    // ====================================================================
    // PROBES - add these to the Vivado wave window from the Objects panel
    // ====================================================================
    wire [31:0] led_data_reg = dut.u_proc.led_data_reg;
    wire [31:0] ra           = dut.u_proc.u_regFile.regs[1];
    wire [31:0] sp           = dut.u_proc.u_regFile.regs[2];
    wire [31:0] s0           = dut.u_proc.u_regFile.regs[8];
    wire [31:0] s1           = dut.u_proc.u_regFile.regs[9];
    wire [31:0] s2           = dut.u_proc.u_regFile.regs[18];
    wire [31:0] pc           = dut.u_proc.pc_current;
    wire [31:0] instruction  = dut.u_proc.instruction;

    // ====================================================================
    // Clock generation - 100 MHz
    // ====================================================================
    initial clk = 0;
    always #5 clk = ~clk;

    // ====================================================================
    // Bypass the slow 1 kHz clock divider so simulation runs at full speed
    // ====================================================================
    initial begin
        #1;
        force dut.proc_clk = clk;
        force dut.sw_s2    = switch_in;
    end

    // ====================================================================
    // Stimulus - Task C needs no switch input (autonomous program)
    // ====================================================================
    initial begin
        reset     = 1'b1;
        switch_in = 16'd0;
        #50;
        reset = 1'b0;

        // 10 us is enough to see 2+ complete Fibonacci cycles
        // (each cycle 0..55 takes ~4000 ns with DELAY=2)
        #10_000;

        $finish;
    end

endmodule