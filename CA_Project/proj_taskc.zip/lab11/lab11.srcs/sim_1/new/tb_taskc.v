`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module:  tb_taskC
//
// Project Task C testbench - Fibonacci sequence verification.
//
// SETUP IN VIVADO (do all four steps):
//   1. Add task_c_sim.mem to Simulation Sources
//      (right-click Simulation Sources -> Add Sources -> Add Files -> select file
//       -> set file type to Memory File)
//   2. Delete or rename the old tb_taskB.v in Simulation Sources
//   3. Set tb_taskC as the simulation top
//      (right-click tb_taskC in Sources -> Set as Top)
//   4. Run Simulation -> Run Behavioral Simulation
//      Then set runtime to 10 us and click Run
//
// SIGNALS TO ADD TO WAVEFORM (from Objects panel under tb_taskC):
//
//   Signal          Radix               What to verify
//   led_data_reg    Unsigned Decimal    0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 0 (reset)
//   sp              Hex                 Drops 0x1F0 -> 0x1E8 on SHOW_AND_DELAY (stack proof)
//   ra              Hex                 Changes on every JAL/JALR
//   s0              Unsigned Decimal    'previous' Fibonacci value
//   s1              Unsigned Decimal    'current' Fibonacci value
//   s2              Unsigned Decimal    'next' Fibonacci value
//   pc              Hex                 Program counter
//
// EXPECTED TIMING (with task_c_sim.mem, DELAY=2):
//    125 ns  led=0   (first display)
//    725 ns  led=1
//   1055 ns  led=1   (F2 = 0+1)
//   1385 ns  led=2
//   1715 ns  led=3
//   2045 ns  led=5
//   2375 ns  led=8
//   2705 ns  led=13
//   3035 ns  led=21
//   3365 ns  led=34
//   3695 ns  led=55
//   3975 ns  led=0   (BGE detects 89>=64, sequence resets)
//   4295 ns  led=1   (second cycle starts)
//
// IMPORTANT: task_c_sim.mem has DELAY=2 (hardware file task_c.mem has DELAY=20).
//            Hardware file is UNTOUCHED. Only simulation uses the fast version.
//////////////////////////////////////////////////////////////////////////////////
module tb_taskC;

    reg         clk;
    reg         reset;
    reg [15:0]  switch_in;
    wire [15:0] leds;

    // ---- DUT: task_c_sim.mem overrides the default MEM_FILE parameter ----
    TopLevelFPGA #(.MEM_FILE("taskc_sim.mem")) dut (
        .clk       (clk),
        .reset     (reset),
        .switch_in (switch_in),
        .leds      (leds)
    );

    // ====================================================================
    // PROBES
    // ====================================================================
    wire [31:0] led_data_reg = dut.u_proc.led_data_reg;
    wire [31:0] ra           = dut.u_proc.u_regFile.regs[1];
    wire [31:0] sp           = dut.u_proc.u_regFile.regs[2];
    wire [31:0] s0           = dut.u_proc.u_regFile.regs[8];
    wire [31:0] s1           = dut.u_proc.u_regFile.regs[9];
    wire [31:0] s2           = dut.u_proc.u_regFile.regs[18];
    wire [31:0] pc           = dut.u_proc.pc_current;
    wire [31:0] instruction  = dut.u_proc.instruction;

    // ====================================================================
    // Clock - 100 MHz
    // ====================================================================
    initial clk = 0;
    always #5 clk = ~clk;

    // ====================================================================
    // Bypass the slow 1 kHz clock divider for simulation speed
    // ====================================================================
    initial begin
        #1;
        force dut.proc_clk = clk;
        force dut.sw_s2    = switch_in;
    end

    // ====================================================================
    // Stimulus
    // NO $finish - Vivado runtime setting controls simulation stop time.
    // Set Vivado runtime to 10 us to see 2+ complete Fibonacci cycles.
    // ====================================================================
    initial begin
        reset     = 1'b1;
        switch_in = 16'd0;
        #50;
        reset = 1'b0;
    end

endmodule