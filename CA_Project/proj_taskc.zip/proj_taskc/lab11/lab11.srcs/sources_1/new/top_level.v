`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// File:   top_level.v
// Contents:
//   (1) TopLevelProcessor - the single-cycle RISC-V core (our Lab 11
//       design, extended with JAL/JALR/LUI/BLT support for Parts B and C).
//   (2) TopLevelFPGA      - a thin board wrapper that adds the 100->10 MHz
//       clock divider and connects the core to the Basys3 switches and LEDs.
//
// CHANGES vs Lab 11 top_level.v:
//   - 2-bit MemtoReg writeback mux (ALU / mem-or-switch / PC+4) so we can
//     write PC+4 into rd for JAL and JALR.
//   - Jump and JumpReg control signals override PC selection.
//   - JALR target computed from ALUResult with LSB cleared (RISC-V spec).
//   - Branch condition decoder extended:
//         funct3=000 BEQ,  funct3=001 BNE,
//         funct3=100 BLT,  funct3=101 BGE
//     BEQ/BNE use the Zero flag; BLT/BGE use ALUResult[0] (from SLT).
//   - MEM_FILE is a parameter so the same core can be wired to Task A, B or
//     C's instruction memory without touching this file.
//////////////////////////////////////////////////////////////////////////////////

// =============================================================================
//  (1) TopLevelProcessor - single-cycle RV32I core
// =============================================================================
module TopLevelProcessor #(
    parameter MEM_FILE = "shift_and_add_mul.mem"
)(
    input  wire        clk,
    input  wire        reset,
    input  wire [5:0]  switch_in,
    output wire [5:0]  led_out,
    output wire        led_write_en
);

    // ---------- FETCH ----------
    wire [31:0] pc_current, pc_plus4, pc_next_val, instruction;

    ProgramCounter u_PC (
        .clk    (clk),
        .reset  (reset),
        .pc_in  (pc_next_val),
        .pc_out (pc_current)
    );
    pcAdder u_pcAdder (
        .pc      (pc_current),
        .pc_next (pc_plus4)
    );
    instructionMemory #(.MEM_FILE(MEM_FILE)) u_iMem (
        .instAddress (pc_current),
        .instruction (instruction)
    );

    // ---------- DECODE ----------
    wire [6:0] opcode = instruction[6:0];
    wire [4:0] rd     = instruction[11:7];
    wire [2:0] funct3 = instruction[14:12];
    wire [4:0] rs1    = instruction[19:15];
    wire [4:0] rs2    = instruction[24:20];
    wire [6:0] funct7 = instruction[31:25];

    wire        RegWrite, MemRead, MemWrite, ALUSrc, Branch, Jump, JumpReg;
    wire [1:0]  ALUOp, MemtoReg;

    MainControl u_MainCtrl (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch),
        .Jump     (Jump),
        .JumpReg  (JumpReg)
    );

    wire [31:0] imm_val;
    immGen u_immGen (
        .inst (instruction),
        .imm  (imm_val)
    );

    wire [31:0] ReadData1, ReadData2, WriteBackData;
    RegisterFile u_regFile (
        .clk         (clk),
        .rst         (reset),
        .WriteEnable (RegWrite),
        .rs1         (rs1),
        .rs2         (rs2),
        .rd          (rd),
        .WriteData   (WriteBackData),
        .ReadData1   (ReadData1),
        .ReadData2   (ReadData2)
    );

    // ---------- EXECUTE ----------
    wire [31:0] alu_src_b;
    mux2 u_aluSrcMux (
        .d0  (ReadData2),
        .d1  (imm_val),
        .sel (ALUSrc),
        .y   (alu_src_b)
    );

    wire [3:0] alu_ctrl;
    ALUControl u_ALUCtrl (
        .opcode     (opcode),
        .ALUOp      (ALUOp),
        .funct3     (funct3),
        .funct7     (funct7),
        .ALUControl (alu_ctrl)
    );

    wire [31:0] alu_result;
    wire        zero_flag;
    ALU u_ALU (
        .ALUControl (alu_ctrl),
        .A          (ReadData1),
        .B          (alu_src_b),
        .ALUResult  (alu_result),
        .Zero       (zero_flag)
    );

    // ---------- BRANCH & JUMP DECISION ----------
    wire [31:0] branch_target;
    branchAdder u_branchAdder (
        .pc            (pc_current),
        .imm           (imm_val),
        .branch_target (branch_target)
    );

    // Branch taken decoding. For B-type:
    //   funct3=000 BEQ  -> taken if Zero=1
    //   funct3=001 BNE  -> taken if Zero=0
    //   funct3=100 BLT  -> taken if ALUResult[0]=1 (SLT produced 1)
    //   funct3=101 BGE  -> taken if ALUResult[0]=0
    // Using funct3[2] to pick between Zero path (0) and SLT path (1), and
    // funct3[0] to invert.
    wire cmp_signal   = (funct3[2] == 1'b0) ? zero_flag : alu_result[0];
    wire branch_taken = Branch & (cmp_signal ^ funct3[0]);

    // JALR target: rs1 + imm (ALU result) with LSB cleared
    wire [31:0] jalr_target = {alu_result[31:1], 1'b0};

    // PC select priority:  JALR > (JAL | Branch-taken) > PC+4
    assign pc_next_val = JumpReg                ? jalr_target   :
                         (Jump | branch_taken)  ? branch_target :
                         pc_plus4;

    // ---------- MEMORY (with address decoder for MMIO) ----------
    wire dmem_wr, dmem_rd, led_wr, sw_rd_en;
    AddressDecoder u_addrDec (
        .address          (alu_result),
        .readEnable       (MemRead),
        .writeEnable      (MemWrite),
        .DataMemWrite     (dmem_wr),
        .DataMemRead      (dmem_rd),
        .LEDWrite         (led_wr),
        .SwitchReadEnable (sw_rd_en)
    );

    wire [31:0] mem_read_data;
    DataMemory u_dataMem (
        .clk        (clk),
        .MemWrite   (dmem_wr),
        .MemRead    (dmem_rd),
        .funct3     (funct3),
        .address    (alu_result),
        .write_data (ReadData2),
        .read_data  (mem_read_data)
    );

    // If the load address hits the switch region, return the 6-bit switch value
    // zero-extended. Otherwise return data-memory output.
    wire [31:0] mem_or_switch = sw_rd_en ? {26'b0, switch_in} : mem_read_data;

    // ---------- WRITEBACK (3-way mux) ----------
    //   00 = ALUResult (R-type, I-type ALU, LUI)
    //   01 = memory / switch data (loads)
    //   10 = PC+4 (JAL, JALR)
    assign WriteBackData = (MemtoReg == 2'b01) ? mem_or_switch :
                           (MemtoReg == 2'b10) ? pc_plus4      :
                                                  alu_result;

    // ---------- BOARD OUTPUT: LED latch at 0x200 ----------
    reg [5:0] led_reg;
    always @(posedge clk) begin
        if (reset)
            led_reg <= 6'b0;
        else if (led_wr)
            led_reg <= ReadData2[5:0];
    end
    assign led_out      = led_reg;
    assign led_write_en = led_wr;

endmodule


// =============================================================================
//  (2) TopLevelFPGA - board wrapper (clock divider + input synchronizers)
//
//  The physical W5 pin is 100 MHz. The clock divider drops it to 10 MHz so
//  our single-cycle datapath has ~100 ns to settle per instruction. BTNC is
//  the reset button; SW[5:0] and LD[5:0] go to the core.
// =============================================================================
module TopLevelFPGA #(
    parameter MEM_FILE = "shift_and_add_mul.mem"
)(
    input  wire        clk,              // 100 MHz on-board oscillator (W5)
    input  wire        reset,            // BTNC (U18) - asynchronous
    input  wire [5:0]  switch_in,        // SW[5:0]
    output wire [5:0]  led_out,          // LD[5:0]
    output wire        led_write_en      // LD15: pulses when core writes LEDs
);
    // 100 MHz -> 10 MHz processor clock
    wire proc_clk;
    clk_divider u_clkdiv (
        .clk_in  (clk),
        .rst     (reset),
        .clk_out (proc_clk)
    );

    // 2-stage synchronizers for switches crossing into proc_clk domain
    reg [5:0] sw_s1, sw_s2;
    always @(posedge proc_clk or posedge reset) begin
        if (reset) begin
            sw_s1 <= 6'd0;
            sw_s2 <= 6'd0;
        end else begin
            sw_s1 <= switch_in;
            sw_s2 <= sw_s1;
        end
    end

    TopLevelProcessor #(.MEM_FILE(MEM_FILE)) u_proc (
        .clk          (proc_clk),
        .reset        (reset),
        .switch_in    (sw_s2),
        .led_out      (led_out),
        .led_write_en (led_write_en)
    );
endmodule