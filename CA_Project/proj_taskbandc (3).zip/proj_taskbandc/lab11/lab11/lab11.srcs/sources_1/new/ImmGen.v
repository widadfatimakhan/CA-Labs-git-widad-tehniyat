////////////////////////////////////////////////////////////////////////////////////
//// Company: 
//// Engineer: 
//// 
//// Create Date: 04/11/2026 10:42:59 AM
//// Design Name: 
//// Module Name: ImmGen
//// Project Name: 
//// Target Devices: 
//// Tool Versions: 
//// Description: 
//// 
//// Dependencies: 
//// 
//// Revision:
//// Revision 0.01 - File Created
//// Additional Comments:
//// 
////////////////////////////////////////////////////////////////////////////////////

//`timescale 1ns / 1ps

//module immGen(
//    input wire [31:0] inst,
//    output reg [31:0] imm
//);
//    wire [6:0] opcode = inst[6:0];
//    always @(*) begin
//        case (opcode)
//            7'b0010011,
//            7'b0000011,
//            7'b1100111: imm = {{20{inst[31]}}, inst[31:20]}; // I-type
//            7'b0100011: imm = {{20{inst[31]}}, inst[31:25],
//            inst[11:7]}; // S-type
//            7'b1100011: imm = {{21{inst[31]}}, inst[7],
//            inst[30:25], inst[11:8]}; // B-type
//            default: imm = 32'b0;
//        endcase
//    end
//endmodule
`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// immGen - Extended for Course Project
//
// CHANGES from the original Lab-11 file:
//
//   1. B-type fix: original was missing the explicit LSB = 1'b0
//      (branch offsets were arriving half-size at the branch adder)
//
//   2. NEW J-type (JAL, opcode 1101111):
//      Bit layout: inst[31|19:12|20|30:21] with LSB forced 0
//      Without this case imm_val = 0 for every JAL, causing the
//      processor to jump to PC+0 (infinite loop) instead of the target.
//
//   3. NEW U-type (LUI opcode 0110111):
//      imm = { inst[31:12], 12'b0 }
//      Without this case imm_val = 0 for LUI, so rd is always written 0.
//
// All original I-type and S-type cases are completely unchanged.
//////////////////////////////////////////////////////////////////////////////////

module immGen (
    input  wire [31:0] inst,
    output reg  [31:0] imm
);
    wire [6:0] opcode = inst[6:0];

    always @(*) begin
        case (opcode)

            // ---- ORIGINAL (unchanged) ----
            7'b0010011,     // I-type ALU : ADDI, SLTI, ANDI, ORI ...
            7'b0000011,     // Load       : LW, LH, LB, LHU, LBU
            7'b1100111:     // JALR
                imm = {{20{inst[31]}}, inst[31:20]};

            7'b0100011:     // S-type Store : SW, SH, SB
                imm = {{20{inst[31]}}, inst[31:25], inst[11:7]};

            // B-type: LSB is always 0 (instruction addresses are 4-byte aligned)
            7'b1100011:     // Branch : BEQ, BNE
                imm = {{20{inst[31]}}, inst[7], inst[30:25], inst[11:8], 1'b0};

            // ---- NEW: J-type (JAL) ----
            // Encoding scatters the offset across the instruction word:
            //   inst[31]    -> imm[20]   (sign bit)
            //   inst[19:12] -> imm[19:12]
            //   inst[20]    -> imm[11]
            //   inst[30:21] -> imm[10:1]
            //   imm[0]      -> 0  (always aligned)
            7'b1101111:
                imm = {{12{inst[31]}}, inst[19:12], inst[20], inst[30:21], 1'b0};

            // ---- NEW: U-type (LUI) ----
            // Upper 20 bits of the instruction become bits [31:12] of imm;
            // lower 12 bits are forced to zero.
            7'b0110111:
                imm = {inst[31:12], 12'b0};

            default: imm = 32'b0;
        endcase
    end
endmodule