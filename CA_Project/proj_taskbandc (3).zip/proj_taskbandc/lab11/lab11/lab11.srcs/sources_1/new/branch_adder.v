//`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////////
//// Company: 
//// Engineer: 
//// 
//// Create Date: 04/11/2026 10:35:05 AM
//// Design Name: 
//// Module Name: branch_adder
//// Project Name: 
//// Target Devices: 
//// Tool Versions: 
//// Description: 
//// 
//// Dependencies: 
//// 
//// Revision:
//// Revision 0.01 - File Created
//// Additional Comments:
//// 
////////////////////////////////////////////////////////////////////////////////////

//module branchAdder(
//    input wire [31:0] pc,
//    input wire [31:0] imm,
//    output wire [31:0] branch_target
//);
//    assign branch_target = pc + (imm << 1);
//endmodule

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// branch_adder - Bug fix: removed (imm << 1)
//
// ImmGen now correctly includes the LSB=0 in the B-type immediate,
// so we just add pc + imm directly. The old (imm << 1) was double-shifting
// which made every branch go to the wrong address.
//////////////////////////////////////////////////////////////////////////////////

module branchAdder(
    input  wire [31:0] pc,
    input  wire [31:0] imm,
    output wire [31:0] branch_target
);
    assign branch_target = pc + imm;
endmodule