
//`timescale 1ns / 1ps

//module TopLevelProcessor (
//    input  wire        clk,
//    input  wire        reset,
//    input  wire [5:0]  switch_in,
//    output wire [5:0]  led_out,
//    output wire        led_write_en
//);

//    // =====================================================================
//    //  FETCH - PC register + PC+4 adder + instruction ROM
//    // =====================================================================

//    wire [31:0] pc_current;
//    wire [31:0] pc_plus4;
//    wire [31:0] pc_next_val;
//    wire [31:0] instruction;

//    ProgramCounter u_PC (
//        .clk    (clk),
//        .reset  (reset),
//        .pc_in  (pc_next_val),
//        .pc_out (pc_current)
//    );

//    pcAdder u_pcAdder (
//        .pc      (pc_current),
//        .pc_next (pc_plus4)
//    );

//    instructionMemory u_iMem (
//        .instAddress (pc_current),
//        .instruction (instruction)
//    );

//    // =====================================================================
//    //  DECODE - instruction fields + control + immediates + register file
//    // =====================================================================

//    wire [6:0] opcode = instruction[6:0];
//    wire [4:0] rd     = instruction[11:7];
//    wire [2:0] funct3 = instruction[14:12];
//    wire [4:0] rs1    = instruction[19:15];
//    wire [4:0] rs2    = instruction[24:20];
//    wire [6:0] funct7 = instruction[31:25];

//    wire        RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
//    wire [1:0]  ALUOp;

//    MainControl u_MainCtrl (
//        .opcode   (opcode),
//        .RegWrite (RegWrite),
//        .ALUOp    (ALUOp),
//        .MemRead  (MemRead),
//        .MemWrite (MemWrite),
//        .ALUSrc   (ALUSrc),
//        .MemtoReg (MemtoReg),
//        .Branch   (Branch)
//    );

//    wire [31:0] imm_val;

//    immGen u_immGen (
//        .inst (instruction),
//        .imm  (imm_val)
//    );

//    wire [31:0] ReadData1, ReadData2, WriteBackData;

//    RegisterFile u_regFile (
//        .clk         (clk),
//        .rst         (reset),
//        .WriteEnable (RegWrite),
//        .rs1         (rs1),
//        .rs2         (rs2),
//        .rd          (rd),
//        .WriteData   (WriteBackData),
//        .ReadData1   (ReadData1),
//        .ReadData2   (ReadData2)
//    );

//    // =====================================================================
//    //  EXECUTE - ALU source mux + ALU control + ALU + branch decision
//    // =====================================================================

//    wire [31:0] alu_src_b;

//    mux2 u_aluSrcMux (
//        .d0  (ReadData2),       // sel=0: register rs2
//        .d1  (imm_val),         // sel=1: sign-extended immediate
//        .sel (ALUSrc),
//        .y   (alu_src_b)
//    );

//    wire [3:0] alu_ctrl;

//    ALUControl u_ALUCtrl (
//        .opcode     (opcode),
//        .ALUOp      (ALUOp),
//        .funct3     (funct3),
//        .funct7     (funct7),
//        .ALUControl (alu_ctrl)
//    );

//    wire [31:0] alu_result;
//    wire        zero_flag;

//    ALU u_ALU (
//        .ALUControl (alu_ctrl),
//        .A          (ReadData1),
//        .B          (alu_src_b),
//        .ALUResult  (alu_result),
//        .Zero       (zero_flag)
//    );

//    // --- Branch target + PCSrc decision ---
//    wire [31:0] branch_target;

//    branchAdder u_branchAdder (
//        .pc            (pc_current),
//        .imm           (imm_val),
//        .branch_target (branch_target)
//    );

//    //  funct3[0] distinguishes BEQ (0) from BNE (1):
//    //    BEQ (funct3=000): take branch when zero_flag == 1
//    //    BNE (funct3=001): take branch when zero_flag == 0
//    wire branch_cond = (funct3[0] == 1'b0) ? zero_flag : ~zero_flag;
//    wire pc_src      = Branch & branch_cond;

//    mux2 u_pcSrcMux (
//        .d0  (pc_plus4),        // sel=0: next sequential instruction
//        .d1  (branch_target),   // sel=1: branch target
//        .sel (pc_src),
//        .y   (pc_next_val)
//    );

//    // =====================================================================
//    //  MEMORY - address decoder + data memory + switch override
//    // =====================================================================

//    wire dmem_wr, dmem_rd, led_wr, sw_rd_en;

//    AddressDecoder u_addrDec (
//        .address          (alu_result),
//        .readEnable       (MemRead),
//        .writeEnable      (MemWrite),
//        .DataMemWrite     (dmem_wr),
//        .DataMemRead      (dmem_rd),
//        .LEDWrite         (led_wr),
//        .SwitchReadEnable (sw_rd_en)
//    );

//    wire [31:0] mem_read_data;

//    DataMemory u_dataMem (
//        .clk        (clk),
//        .MemWrite   (dmem_wr),
//        .MemRead    (dmem_rd),
//        .funct3     (funct3),
//        .address    (alu_result),
//        .write_data (ReadData2),
//        .read_data  (mem_read_data)
//    );

//    // Switch override: when reading from address region 0x200, return switches
//    wire [31:0] mem_or_switch = sw_rd_en ? {26'b0, switch_in} : mem_read_data;

//    // =====================================================================
//    //  WRITEBACK - select ALU result or memory data into register file
//    // =====================================================================

//    mux2 u_wbMux (
//        .d0  (alu_result),      // sel=0: ALU result (R-type / I-type)
//        .d1  (mem_or_switch),   // sel=1: memory or switch data (loads)
//        .sel (MemtoReg),
//        .y   (WriteBackData)
//    );

//    // =====================================================================
//    //  BOARD I/O - LED output register
//    // =====================================================================

//    reg [5:0] led_reg;

//    always @(posedge clk) begin
//        if (reset)
//            led_reg <= 6'b0;
//        else if (led_wr)
//            led_reg <= ReadData2[5:0];
//    end

//    assign led_out      = led_reg;
//    assign led_write_en = led_wr;

//endmodule

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// top_level - Extended with JAL and LUI support
//
// CHANGES from original:
//   1. MainControl instantiation: added JumpAndLink and LUILoad ports
//   2. PC mux: extended from 2-way to 3-way (PC+4 / Branch / JAL)
//   3. Writeback mux: extended from 2-way to 4-way
//        00 = ALU result     (original)
//        01 = Mem/Switch     (original)
//        10 = PC+4           (NEW - JAL saves return address)
//        11 = Immediate      (NEW - LUI writes upper immediate)
//
// Everything else is completely unchanged from your original.
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps

module TopLevelProcessor (
    input  wire        clk,
    input  wire        reset,
    input  wire [5:0]  switch_in,
    output wire [5:0]  led_out,
    output wire        led_write_en
);

    // =====================================================================
    //  FETCH
    // =====================================================================
    wire [31:0] pc_current, pc_plus4, pc_next_val, instruction;

    ProgramCounter u_PC (
        .clk    (clk),
        .reset  (reset),
        .pc_in  (pc_next_val),
        .pc_out (pc_current)
    );

    pcAdder u_pcAdder (
        .pc      (pc_current),
        .pc_next (pc_plus4)
    );

    instructionMemory u_iMem (
        .instAddress (pc_current),
        .instruction (instruction)
    );

    // =====================================================================
    //  DECODE
    // =====================================================================
    wire [6:0] opcode = instruction[6:0];
    wire [4:0] rd     = instruction[11:7];
    wire [2:0] funct3 = instruction[14:12];
    wire [4:0] rs1    = instruction[19:15];
    wire [4:0] rs2    = instruction[24:20];
    wire [6:0] funct7 = instruction[31:25];

    wire        RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire        JumpAndLink, LUILoad;   // NEW
    wire [1:0]  ALUOp;

    MainControl u_MainCtrl (
        .opcode      (opcode),
        .RegWrite    (RegWrite),
        .ALUOp       (ALUOp),
        .MemRead     (MemRead),
        .MemWrite    (MemWrite),
        .ALUSrc      (ALUSrc),
        .MemtoReg    (MemtoReg),
        .Branch      (Branch),
        .JumpAndLink (JumpAndLink),     // NEW
        .LUILoad     (LUILoad)          // NEW
    );

    wire [31:0] imm_val;

    immGen u_immGen (
        .inst (instruction),
        .imm  (imm_val)
    );

    wire [31:0] ReadData1, ReadData2, WriteBackData;

    RegisterFile u_regFile (
        .clk         (clk),
        .rst         (reset),
        .WriteEnable (RegWrite),
        .rs1         (rs1),
        .rs2         (rs2),
        .rd          (rd),
        .WriteData   (WriteBackData),
        .ReadData1   (ReadData1),
        .ReadData2   (ReadData2)
    );

    // =====================================================================
    //  EXECUTE
    // =====================================================================
    wire [31:0] alu_src_b;

    mux2 u_aluSrcMux (
        .d0  (ReadData2),
        .d1  (imm_val),
        .sel (ALUSrc),
        .y   (alu_src_b)
    );

    wire [3:0] alu_ctrl;

    ALUControl u_ALUCtrl (
        .opcode     (opcode),
        .ALUOp      (ALUOp),
        .funct3     (funct3),
        .funct7     (funct7),
        .ALUControl (alu_ctrl)
    );

    wire [31:0] alu_result;
    wire        zero_flag;

    ALU u_ALU (
        .ALUControl (alu_ctrl),
        .A          (ReadData1),
        .B          (alu_src_b),
        .ALUResult  (alu_result),
        .Zero       (zero_flag)
    );

    // --- Branch target ---
    wire [31:0] branch_target;

    branchAdder u_branchAdder (
        .pc            (pc_current),
        .imm           (imm_val),
        .branch_target (branch_target)
    );

    // BEQ (funct3=000): branch when zero=1
    // BNE (funct3=001): branch when zero=0
    wire branch_cond = (funct3[0] == 1'b0) ? zero_flag : ~zero_flag;
    wire take_branch = Branch & branch_cond;

    // NEW: JAL target = PC + J-imm
    wire [31:0] jal_target = pc_current + imm_val;

    // NEW: 3-way PC mux - JAL takes priority over branch over PC+4
    assign pc_next_val = JumpAndLink ? jal_target    :
                         take_branch  ? branch_target :
                                        pc_plus4;

    // =====================================================================
    //  MEMORY
    // =====================================================================
    wire dmem_wr, dmem_rd, led_wr, sw_rd_en;

    AddressDecoder u_addrDec (
        .address          (alu_result),
        .readEnable       (MemRead),
        .writeEnable      (MemWrite),
        .DataMemWrite     (dmem_wr),
        .DataMemRead      (dmem_rd),
        .LEDWrite         (led_wr),
        .SwitchReadEnable (sw_rd_en)
    );

    wire [31:0] mem_read_data;

    DataMemory u_dataMem (
        .clk        (clk),
        .MemWrite   (dmem_wr),
        .MemRead    (dmem_rd),
        .funct3     (funct3),
        .address    (alu_result),
        .write_data (ReadData2),
        .read_data  (mem_read_data)
    );

    wire [31:0] mem_or_switch = sw_rd_en ? {26'b0, switch_in} : mem_read_data;

    // =====================================================================
    //  WRITEBACK - NEW 4-way mux
    //    Priority: LUI > JAL > Load > ALU
    // =====================================================================
    assign WriteBackData = LUILoad     ? imm_val      :  // LUI: upper immediate
                           JumpAndLink ? pc_plus4      :  // JAL: return address
                           MemtoReg    ? mem_or_switch :  // Load: memory data
                                         alu_result;      // ALU result

    // =====================================================================
    //  BOARD I/O
    // =====================================================================
    reg [5:0] led_reg;

    always @(posedge clk) begin
        if (reset)
            led_reg <= 6'b0;
        else if (led_wr)
            led_reg <= ReadData2[5:0];
    end

    assign led_out      = led_reg;
    assign led_write_en = led_wr;

endmodule