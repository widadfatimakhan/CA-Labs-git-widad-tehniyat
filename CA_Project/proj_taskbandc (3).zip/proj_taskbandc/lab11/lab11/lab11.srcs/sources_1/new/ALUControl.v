//`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////////
//// Company: 
//// Engineer: 
//// 
//// Create Date: 04/11/2026 11:58:20 AM
//// Design Name: 
//// Module Name: ALUControl
//// Project Name: 
//// Target Devices: 
//// Tool Versions: 
//// Description: 
//// 
//// Dependencies: 
//// 
//// Revision:
//// Revision 0.01 - File Created
//// Additional Comments:
//// 
////////////////////////////////////////////////////////////////////////////////////

//module ALUControl (
//    input  [6:0] opcode,
//    input  [1:0] ALUOp,
//    input  [2:0] funct3,
//    input  [6:0] funct7,
//    output reg [3:0] ALUControl
//);
//    always @(*) begin
//        ALUControl = 4'b0010; // default: ADD

//        case (ALUOp)
//            2'b00: ALUControl = 4'b0010; // ADD (load/store)
//            2'b01: ALUControl = 4'b0110; // SUB (BEQ)
//            2'b10: begin
//                case (funct3)
//                    3'b000: ALUControl = (opcode == 7'b0110011 && funct7 == 7'b0100000)
//                                         ? 4'b0110 : 4'b0010; // SUB or ADD
//                    3'b001: ALUControl = 4'b0100; // SLL
//                    3'b100: ALUControl = 4'b0011; // XOR
//                    3'b101: ALUControl = 4'b0101; // SRL
//                    3'b110: ALUControl = 4'b0001; // OR
//                    3'b111: ALUControl = 4'b0000; // AND
//                    default: ALUControl = 4'b0010;
//                endcase
//            end
//            default: ALUControl = 4'b0010;
//        endcase
//    end
//endmodule

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// ALUControl - Extended with SLTI
//
// CHANGE: funct3=010 now maps to 4'b1000 (SLT/SLTI)
// All original mappings completely unchanged.
//
// ALU control codes (from your ALU_module.v):
//   0000 = ADD
//   0001 = SUB
//   0010 = AND
//   0011 = OR
//   0100 = XOR
//   0101 = SLL
//   0110 = SRL
//   0111 = BEQ helper
//   1000 = SLT (NEW - Set Less Than, used for SLTI)
//////////////////////////////////////////////////////////////////////////////////

module ALUControl (
    input  [6:0] opcode,
    input  [1:0] ALUOp,
    input  [2:0] funct3,
    input  [6:0] funct7,
    output reg [3:0] ALUControl
);
    always @(*) begin
        ALUControl = 4'b0000; // default: ADD

        case (ALUOp)
            2'b00: ALUControl = 4'b0000; // ADD (load/store)
            2'b01: ALUControl = 4'b0111; // SUB/BEQ helper
            2'b10: begin
                case (funct3)
                    // ---- ORIGINAL ----
                    3'b000: ALUControl = (opcode == 7'b0110011 && funct7 == 7'b0100000)
                                         ? 4'b0001  // SUB
                                         : 4'b0000; // ADD (ADDI or R-ADD)
                    3'b001: ALUControl = 4'b0101; // SLL / SLLI
                    3'b100: ALUControl = 4'b0100; // XOR / XORI
                    3'b101: ALUControl = 4'b0110; // SRL / SRLI
                    3'b110: ALUControl = 4'b0011; // OR  / ORI
                    3'b111: ALUControl = 4'b0010; // AND / ANDI

                    // ---- NEW: SLTI (funct3=010) ----
                    3'b010: ALUControl = 4'b1000; // SLT / SLTI

                    default: ALUControl = 4'b0000;
                endcase
            end
            default: ALUControl = 4'b0000;
        endcase
    end
endmodule