////`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////////
////// Company: 
////// Engineer: 
////// 
////// Create Date: 04/11/2026 11:57:34 AM
////// Design Name: 
////// Module Name: MainControl
////// Project Name: 
////// Target Devices: 
////// Tool Versions: 
////// Description: 
////// 
////// Dependencies: 
////// 
////// Revision:
////// Revision 0.01 - File Created
////// Additional Comments:
////// 
//////////////////////////////////////////////////////////////////////////////////////

////module MainControl (
////    input  [6:0] opcode,
////    output reg   RegWrite,
////    output reg [1:0] ALUOp,
////    output reg   MemRead,
////    output reg   MemWrite,
////    output reg   ALUSrc,
////    output reg   MemtoReg,
////    output reg   Branch
////);
////    always @(*) begin
////        // defaults
////        RegWrite = 0; ALUOp = 2'b00; MemRead = 0;
////        MemWrite = 0; ALUSrc = 0; MemtoReg = 0; Branch = 0;

////        case (opcode)
////            7'b0110011: begin // R-type
////                RegWrite = 1; ALUOp = 2'b10;
////            end
////            7'b0010011: begin // I-type ALU (ADDI)
////                RegWrite = 1; ALUOp = 2'b10; ALUSrc = 1;
////            end
////            7'b0000011: begin // Load (LW/LH/LB)
////                RegWrite = 1; ALUSrc = 1; MemRead = 1; MemtoReg = 1;
////            end
////            7'b0100011: begin // Store (SW/SH/SB)
////                ALUSrc = 1; MemWrite = 1;
////            end
////            7'b1100011: begin // Branch (BEQ)
////                ALUOp = 2'b01; Branch = 1;
////            end
////        endcase
////    end
////endmodule
//`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////////
//// MainControl - Extended with JAL (J-type) and LUI (U-type)
////
//// NEW outputs:
////   JumpAndLink - set for JAL: PC <- PC+imm, rd <- PC+4
////   LUILoad     - set for LUI: rd <- upper immediate
////
//// All original cases completely unchanged.
////////////////////////////////////////////////////////////////////////////////////

//module MainControl (
//    input  [6:0] opcode,
//    output reg   RegWrite,
//    output reg [1:0] ALUOp,
//    output reg   MemRead,
//    output reg   MemWrite,
//    output reg   ALUSrc,
//    output reg   MemtoReg,
//    output reg   Branch,
//    // NEW
//    output reg   JumpAndLink,
//    output reg   LUILoad
//);
//    always @(*) begin
//        // defaults
//        RegWrite = 0; ALUOp = 2'b00; MemRead  = 0;
//        MemWrite = 0; ALUSrc = 0;    MemtoReg = 0;
//        Branch   = 0; JumpAndLink = 0; LUILoad = 0;

//        case (opcode)
//            // ---- ORIGINAL - unchanged ----
//            7'b0110011: begin // R-type
//                RegWrite = 1; ALUOp = 2'b10;
//            end
//            7'b0010011: begin // I-type ALU (ADDI, SLTI)
//                RegWrite = 1; ALUOp = 2'b10; ALUSrc = 1;
//            end
//            7'b0000011: begin // Load
//                RegWrite = 1; ALUSrc = 1; MemRead = 1; MemtoReg = 1;
//            end
//            7'b0100011: begin // Store
//                ALUSrc = 1; MemWrite = 1;
//            end
//            7'b1100011: begin // Branch
//                ALUOp = 2'b01; Branch = 1;
//            end

//            // ---- NEW: JAL opcode 1101111 ----
//            7'b1101111: begin
//                RegWrite    = 1;
//                JumpAndLink = 1;
//            end

//            // ---- NEW: LUI opcode 0110111 ----
//            7'b0110111: begin
//                RegWrite = 1;
//                LUILoad  = 1;
//            end
//        endcase
//    end
//endmodule
`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// ImmGen - Extended with J-type (JAL) and U-type (LUI)
//
// CHANGES:
//   1. B-type bug fix: was missing 1'b0 LSB - offsets were halved
//   2. NEW J-type: inst[31,19:12,20,30:21] with LSB=0
//   3. NEW U-type: inst[31:12] shifted to bits [31:12], lower 12 = 0
//
// All original cases unchanged except B-type fix.
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// MainControl - Extended with JAL (J-type) and LUI (U-type)
//
// NEW outputs:
//   JumpAndLink - set for JAL: PC <- PC+imm, rd <- PC+4
//   LUILoad     - set for LUI: rd <- upper immediate
//
// All original cases completely unchanged.
//////////////////////////////////////////////////////////////////////////////////

module MainControl (
    input  [6:0] opcode,
    output reg   RegWrite,
    output reg [1:0] ALUOp,
    output reg   MemRead,
    output reg   MemWrite,
    output reg   ALUSrc,
    output reg   MemtoReg,
    output reg   Branch,
    // NEW
    output reg   JumpAndLink,
    output reg   LUILoad
);
    always @(*) begin
        // defaults
        RegWrite = 0; ALUOp = 2'b00; MemRead  = 0;
        MemWrite = 0; ALUSrc = 0;    MemtoReg = 0;
        Branch   = 0; JumpAndLink = 0; LUILoad = 0;

        case (opcode)
            // ---- ORIGINAL - unchanged ----
            7'b0110011: begin // R-type
                RegWrite = 1; ALUOp = 2'b10;
            end
            7'b0010011: begin // I-type ALU (ADDI, SLTI)
                RegWrite = 1; ALUOp = 2'b10; ALUSrc = 1;
            end
            7'b0000011: begin // Load
                RegWrite = 1; ALUSrc = 1; MemRead = 1; MemtoReg = 1;
            end
            7'b0100011: begin // Store
                ALUSrc = 1; MemWrite = 1;
            end
            7'b1100011: begin // Branch
                ALUOp = 2'b01; Branch = 1;
            end

            // ---- NEW: JAL opcode 1101111 ----
            7'b1101111: begin
                RegWrite    = 1;
                JumpAndLink = 1;
            end

            // ---- NEW: LUI opcode 0110111 ----
            7'b0110111: begin
                RegWrite = 1;
                LUILoad  = 1;
            end
        endcase
    end
endmodule