# ================================================================
# Basys 3 Master XDC for top_rf_alu module
# Digilent Basys 3 Board (XC7A35T-1CPG236C)
# 100 MHz clock, 16 switches, 16 LEDs, BTNC & BTNR buttons
# ================================================================

# ================================================================
# Clock - 100 MHz onboard oscillator
# ================================================================
set_property PACKAGE_PIN W5 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]

# Create 100 MHz clock constraint (period = 10 ns)
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk]

# ================================================================
# Reset - BTNR (right button) - active high
# ================================================================
set_property PACKAGE_PIN T17 [get_ports rst]
set_property IOSTANDARD LVCMOS33 [get_ports rst]

# ================================================================
# Button for manual write pulse - BTNC (center button)
# ================================================================
set_property PACKAGE_PIN U18 [get_ports btn_write]
set_property IOSTANDARD LVCMOS33 [get_ports btn_write]

# ================================================================
# 16 Slide Switches (SW0 = rightmost ? SW15 = leftmost)
# sw[0] = SW0 (least significant bit), sw[15] = SW15 (demo enable)
# ================================================================
set_property PACKAGE_PIN V17 [get_ports {sw[0]}]
set_property PACKAGE_PIN V16 [get_ports {sw[1]}]
set_property PACKAGE_PIN W16 [get_ports {sw[2]}]
set_property PACKAGE_PIN W17 [get_ports {sw[3]}]
set_property PACKAGE_PIN W15 [get_ports {sw[4]}]
set_property PACKAGE_PIN V15 [get_ports {sw[5]}]
set_property PACKAGE_PIN W14 [get_ports {sw[6]}]
set_property PACKAGE_PIN W13 [get_ports {sw[7]}]
set_property PACKAGE_PIN V2  [get_ports {sw[8]}]
set_property PACKAGE_PIN T3  [get_ports {sw[9]}]
set_property PACKAGE_PIN T2  [get_ports {sw[10]}]
set_property PACKAGE_PIN R3  [get_ports {sw[11]}]
set_property PACKAGE_PIN W2  [get_ports {sw[12]}]
set_property PACKAGE_PIN U1  [get_ports {sw[13]}]
set_property PACKAGE_PIN T1  [get_ports {sw[14]}]
set_property PACKAGE_PIN R2  [get_ports {sw[15]}]

set_property IOSTANDARD LVCMOS33 [get_ports {sw[*]}]

# ================================================================
# 16 LEDs (LD0 = rightmost ? LD15 = leftmost)
# led[0] = LD0 (least significant bit)
# ================================================================
set_property PACKAGE_PIN U16 [get_ports {led[0]}]
set_property PACKAGE_PIN E19 [get_ports {led[1]}]
set_property PACKAGE_PIN U19 [get_ports {led[2]}]
set_property PACKAGE_PIN V19 [get_ports {led[3]}]
set_property PACKAGE_PIN W18 [get_ports {led[4]}]
set_property PACKAGE_PIN U15 [get_ports {led[5]}]
set_property PACKAGE_PIN U14 [get_ports {led[6]}]
set_property PACKAGE_PIN V14 [get_ports {led[7]}]
set_property PACKAGE_PIN V13 [get_ports {led[8]}]
set_property PACKAGE_PIN V3  [get_ports {led[9]}]
set_property PACKAGE_PIN W3  [get_ports {led[10]}]
set_property PACKAGE_PIN U3  [get_ports {led[11]}]
set_property PACKAGE_PIN P3  [get_ports {led[12]}]
set_property PACKAGE_PIN N3  [get_ports {led[13]}]
set_property PACKAGE_PIN P1  [get_ports {led[14]}]
set_property PACKAGE_PIN L1  [get_ports {led[15]}]

set_property IOSTANDARD LVCMOS33 [get_ports {led[*]}]

# ================================================================
# Optional: Bitstream / configuration settings
# Usually not needed, but good to include for completeness
# ================================================================
set_property CONFIG_VOLTAGE 3.3 [current_design]
set_property CFGBVS VCCO [current_design]

# Optional: If you see high fanout warnings on slow_clk or fsm_state
# set_property MAX_FANOUT 200 [get_nets slow_clk]
# set_property MAX_FANOUT 200 [get_nets fsm_state]