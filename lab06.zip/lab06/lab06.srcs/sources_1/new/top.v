`timescale 1ns / 1ps

module Top_ALU_System(
    input clk,
    input rst,          // Mapped to Center Button
    input [15:0] sw,    // Physical Switches
    input btn_in,       // Physical Button for calculation
    output [3:0] led_4, // 4 LEDs for output
    output led_zero     // 1 LED for Zero flag
);

    // Internal Signals
    wire [31:0] alu_result;
    wire zero_flag;
    wire db_btn;
    wire [31:0] sw_data_internal;
    
    // Fixed Operands (Procedure e)
    wire [31:0] A = 32'h10101010;
    wire [31:0] B = 32'h01010101;

    // --- 1. Debouncer Instance ---
    debouncer btn_db_inst (
        .clk(clk),
        .pbin(btn_in),
        .pbout(db_btn)
    );

    // --- 2. ALU Instance ---
    ALU_module alu_inst (
        .A(A),
        .B(B),
        .ALUControl(sw[3:0]), 
        .ALUResult(alu_result),
        .Zero(zero_flag)
    );

    // --- 3. Your "leds" Module (Used here to read switches) ---
    wire [31:0] dummy_read_data;
    leds switch_reader (
        .clk(clk),
        .rst(rst),
        .btns(16'b0),
        .writeData(32'b0),
        .writeEnable(1'b0),
        .readEnable(1'b1),
        .memAddress(30'b0),
        .switches(sw),
        .readData(dummy_read_data)
    );

    // --- 4. Your "switches" Module (Used here to drive LEDs) ---
    // Note: This module in your code actually drives the LED output pins
    wire [15:0] full_led_bus;
    switches led_driver (
        .clk(clk),
        .rst(rst),
        .writeData(alu_result),
        .writeEnable(db_btn),
        .readEnable(1'b0),
        .memAddress(30'b0),
        .readData(),
        .leds(full_led_bus)
    );

    // --- 5. Display Paging (32-bit to 4-LED MUX) ---
    reg [3:0] mux_out;
    always @(*) begin
        case (sw[15:13])
            3'b000: mux_out = alu_result[3:0];
            3'b001: mux_out = alu_result[7:4];
            3'b010: mux_out = alu_result[11:8];
            3'b011: mux_out = alu_result[15:12];
            3'b100: mux_out = alu_result[19:16];
            3'b101: mux_out = alu_result[23:20];
            3'b110: mux_out = alu_result[27:24];
            3'b111: mux_out = alu_result[31:28];
            default: mux_out = 4'b0000;
        endcase
    end

    assign led_4 = mux_out;
    assign led_zero = zero_flag;

endmodule