`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 02/26/2026 10:21:02 AM
// Design Name: 
// Module Name: ALU_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module ALU_tb;

    // Inputs (reg)
    reg [31:0] A;
    reg [31:0] B;
    reg [3:0]  ALUControl;

    // Outputs (wire)
    wire [31:0] ALUResult;
    wire Zero;

    // Instantiate the ALU
    ALU_module uut (
        .A(A), 
        .B(B), 
        .ALUControl(ALUControl), 
        .ALUResult(ALUResult), 
        .Zero(Zero)
    );

    initial begin
        // --- Initialization ---
        A = 0; B = 0; ALUControl = 4'b0000;
        
        // Display header in console
        $display("Time\t Control\t A\t\t B\t\t Result\t\t Zero");
        $monitor("%0t\t %b\t\t %h\t %h\t %h\t %b", $time, ALUControl, A, B, ALUResult, Zero);

        #10;

        // --- TEST: AND ---
        A = 32'hFFFF0000; B = 32'hAAAA5555;
        ALUControl = 4'b0000; #10;

        // --- TEST: OR ---
        ALUControl = 4'b0001; #10;

        // --- TEST: XOR ---
        A = 32'hF0F0F0F0; B = 32'hFFFFFFFF;
        ALUControl = 4'b0010; #10;

        // --- TEST: SLL (Shift Left) ---
        A = 32'h00000001; B = 32'd4; // 1 << 4 = 16 (0x10)
        ALUControl = 4'b0011; #10;

        // --- TEST: SRL (Shift Right) ---
        A = 32'h00000080; B = 32'd2; // 128 >> 2 = 32 (0x20)
        ALUControl = 4'b0100; #10;

        // --- TEST: ADD ---
        A = 32'd100; B = 32'd50;
        ALUControl = 4'b1001; #10;

        // --- TEST: SUB (Non-Zero Result) ---
        A = 32'd100; B = 32'd40;
        ALUControl = 4'b1011; #10;

        // --- TEST: SUB (Zero Result) ---
        A = 32'd50; B = 32'd50;
        ALUControl = 4'b1011; #10;

        // --- TEST: DEFAULT CASE ---
        ALUControl = 4'b1111; #10;

        $display("--- All Tests Completed ---");
        $finish;
    end

endmodule