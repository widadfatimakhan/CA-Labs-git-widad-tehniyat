`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/11/2026 11:25:18 AM
// Design Name: 
// Module Name: top_level
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//module TopLevelProcessor(input wire clk, input wire reset);
//// ?? Program flow wires ??
//    wire [31:0] pc_out, pc_plus_4, branch_target, next_pc, instruction;
//    // ?? Control signal wires ??
//    wire Branch, MemRead, MemtoReg, MemWrite, ALUSrc, RegWrite, zero_flag, PCSrc;
//    wire [1:0] ALUOp;
//    wire [3:0] ALU_operation;
//    // ?? Data path wires ??
//    wire [31:0] imm_extended, read_data1, read_data2;
//    wire [31:0] alu_input_b, alu_result, memory_read_data, write_data;
//    assign PCSrc = Branch & zero_flag;
//    // ?? Program flow ??
//    ProgramCounter u_pc (.clk(clk),.reset(reset),.pc_in(next_pc),.pc_out(pc_out));
//    pcAdder u_pcAdder (.pc(pc_out),.pc_next(pc_plus_4));
//    branchAdder u_brAdder (.pc(pc_out),.imm(imm_extended),.branch_target(branch_target));
//    mux2 u_mux_pc_select (.d0(pc_plus_4),.d1(branch_target),.sel(PCSrc),.y(next_pc));
//    // ?? Instruction & control ??
//    instructionMemory u_imem (.instAddress(pc_out),.instruction(instruction));
//    MainControl u_main_ctrl (.opcode(instruction[6:0]),.Branch(Branch),.MemRead(MemRead),.MemtoReg(MemtoReg),.ALUOp(ALUOp),.MemWrite(MemWrite),.ALUSrc(ALUSrc),.RegWrite(RegWrite));
//    ALUControl u_alu_ctrl (.ALUOp(ALUOp),.funct3(instruction[14:12]),.funct7(instruction[31:25]),.ALUControl(ALU_operation));
//    // ?? Datapath execution ??
//    RegisterFile u_reg_file (.clk(clk),.rst(reset),.WriteEnable(RegWrite),.rs1(instruction[19:15]),.rs2(instruction[24:20]),.rd(instruction[11:7]),.WriteData(write_data),.ReadData1(read_data1),.ReadData2(read_data2));
//    immGen u_immGen (.inst(instruction),.imm(imm_extended));
//    mux2 u_mux_alu_src(.d0(read_data2),.d1(imm_extended),.sel(ALUSrc),.y(alu_input_b));
//    ALU u_alu (.A(read_data1),.B(alu_input_b),.ALUControl(ALU_operation),.ALUResult(alu_result),.Zero(zero_flag));
//    // ?? Memory & write-back ??
//    DataMemory u_dmem (.clk(clk),.MemWrite(MemWrite),.MemRead(MemRead),.address(alu_result[7:0]),.write_data(read_data2),.read_data(memory_read_data));
//    mux2 u_mux_writeback(.d0(alu_result),.d1(memory_read_data),.sel(MemtoReg),.y(write_data));
//endmodule

module TopLevelProcessor #(parameter DIV = 5000000)(
    input  wire        clk,
    input  wire        reset,
    output wire [6:0] seg,
    output wire [3:0] an
//    input  wire [5:0]  switch_in,
//    output wire [5:0]  led_out,
//    output wire        led_write_en
);
      wire slow_clk;

    clock_divider #(
        .DIV(DIV)
    ) uClkDiv (
        .clk_in (clk),
        .reset  (reset),
        .clk_out(slow_clk)
    );
    // =====================================================================
    //  FETCH - PC register + PC+4 adder + instruction ROM
    // =====================================================================

    wire [31:0] pc_current;
    wire [31:0] pc_plus4;
    wire [31:0] pc_next_val;
    wire [31:0] instruction;

    ProgramCounter u_PC (
        .clk    (clk),
        .reset  (reset),
        .pc_in  (pc_next_val),
        .pc_out (pc_current)
    );

    pcAdder u_pcAdder (
        .pc      (pc_current),
        .pc_next (pc_plus4)
    );

    instructionMemory u_iMem (
        .instAddress (pc_current),
        .instruction (instruction)
    );

    // =====================================================================
    //  DECODE - instruction fields + control + immediates + register file
    // =====================================================================

    wire [6:0] opcode = instruction[6:0];
    wire [4:0] rd     = instruction[11:7];
    wire [2:0] funct3 = instruction[14:12];
    wire [4:0] rs1    = instruction[19:15];
    wire [4:0] rs2    = instruction[24:20];
    wire [6:0] funct7 = instruction[31:25];

    wire        RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire [1:0]  ALUOp;

    MainControl u_MainCtrl (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUOp    (ALUOp),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .ALUSrc   (ALUSrc),
        .MemtoReg (MemtoReg),
        .Branch   (Branch)
    );

    wire [31:0] imm_val;

    immGen u_immGen (
        .inst (instruction),
        .imm  (imm_val)
    );

    wire [31:0] ReadData1, ReadData2, WriteBackData;

    RegisterFile u_regFile (
        .clk         (clk),
        .rst         (reset),
        .WriteEnable (RegWrite),
        .rs1         (rs1),
        .rs2         (rs2),
        .rd          (rd),
        .WriteData   (WriteBackData),
        .ReadData1   (ReadData1),
        .ReadData2   (ReadData2)
    );

    // =====================================================================
    //  EXECUTE - ALU source mux + ALU control + ALU + branch decision
    // =====================================================================

    wire [31:0] alu_src_b;

    mux2 u_aluSrcMux (
        .d0  (ReadData2),       // sel=0: register rs2
        .d1  (imm_val),         // sel=1: sign-extended immediate
        .sel (ALUSrc),
        .y   (alu_src_b)
    );

    wire [3:0] alu_ctrl;

    ALUControl u_ALUCtrl (
        .opcode     (opcode),
        .ALUOp      (ALUOp),
        .funct3     (funct3),
        .funct7     (funct7),
        .ALUControl (alu_ctrl)
    );

    wire [31:0] alu_result;
    wire        zero_flag;

    ALU u_ALU (
        .ALUControl (alu_ctrl),
        .A          (ReadData1),
        .B          (alu_src_b),
        .ALUResult  (alu_result),
        .Zero       (zero_flag)
    );

    // --- Branch target + PCSrc decision ---
    wire [31:0] branch_target;

    branchAdder u_branchAdder (
        .pc            (pc_current),
        .imm           (imm_val),
        .branch_target (branch_target)
    );

    //  funct3[0] distinguishes BEQ (0) from BNE (1):
    //    BEQ (funct3=000): take branch when zero_flag == 1
    //    BNE (funct3=001): take branch when zero_flag == 0
    wire branch_cond = (funct3[0] == 1'b0) ? zero_flag : ~zero_flag;
    wire pc_src      = Branch & branch_cond;

    mux2 u_pcSrcMux (
        .d0  (pc_plus4),        // sel=0: next sequential instruction
        .d1  (branch_target),   // sel=1: branch target
        .sel (pc_src),
        .y   (pc_next_val)
    );

    // =====================================================================
    //  MEMORY - address decoder + data memory + switch override
    // =====================================================================

    wire dmem_wr, dmem_rd, led_wr, sw_rd_en;

    AddressDecoder u_addrDec (
        .address          (alu_result),
        .readEnable       (MemRead),
        .writeEnable      (MemWrite),
        .DataMemWrite     (dmem_wr),
        .DataMemRead      (dmem_rd),
        .LEDWrite         (led_wr),
        .SwitchReadEnable (sw_rd_en)
    );

    wire [31:0] mem_read_data;

    DataMemory u_dataMem (
        .clk        (clk),
        .MemWrite   (dmem_wr),
        .MemRead    (dmem_rd),
        .funct3     (funct3),
        .address    (alu_result),
        .write_data (ReadData2),
        .read_data  (mem_read_data)
    );

    // Switch override: when reading from address region 0x200, return switches
//    wire [31:0] mem_or_switch = sw_rd_en ? {26'b0, switch_in} : mem_read_data;

    // =====================================================================
    //  WRITEBACK - select ALU result or memory data into register file
    // =====================================================================

    mux2 u_wbMux (
        .d0  (alu_result),      // sel=0: ALU result (R-type / I-type)
        .d1  (mem_or_switch),   // sel=1: memory or switch data (loads)
        .sel (MemtoReg),
        .y   (WriteBackData)
    );

    // =====================================================================
    //  BOARD I/O - LED output register
    // =====================================================================

//    reg [5:0] led_reg;

//    always @(posedge clk) begin
//        if (reset)
//            led_reg <= 6'b0;
//        else if (led_wr)
//            led_reg <= ReadData2[5:0];
//    end

//    assign led_out      = led_reg;
//    assign led_write_en = led_wr;

    reg[31:0] x10_monitor;
    always @(posedge slow_clk) begin
        if (reset)
            x10_monitor <= 32'b0;
        else if (RegWrite && rd == 5'd15)
            x10_monitor <= WriteBackData;
    end 
    
    SevenSegController sevenseg (
        .clk(clk),
        .reset(reset),
        .value(x10_monitor[7:0]),
        .seg(seg),
        .an(an)
    );
endmodule